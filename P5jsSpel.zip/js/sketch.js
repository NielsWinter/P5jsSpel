function setup() {
    //Canvas met Achtergrond zonder lijn er omheen
    createCanvas(600, 600);
    background(0, 220, 200);
    noStroke();
    
    // Niet de cursor laten zien
    noCursor();
    
    // Het balletje ergens boven aan op een random plek op de X as laten beginnen
    valY = 0;
    valX = random(0,600);

    // Score begint als 0
    score = 0;

    // Zorgen dat de muis in het midden van het balkje zit
    rectX = mouseX - 50;
}

// Reset functie die alle waardes op 0 gooit voor aan het einde van het spel
function reset() {
    valY = 0;
    valX = random(0, 600);
    score = 0;
    gameOver = 0;
}

function draw() {
    // Balkje
    background(0, 220, 200);
    fill(250);
    rect(rectX, 550, 100, 20);
    
    // Zorg dat het balkje altijd helemaal in beeld is
    if (mouseX < 50){
        rectX = 0;
    } else {rectX = mouseX - 50;}
    if (mouseX > 550){
        rectX = 500;
    }

    // Maak een balletje die valt
    fill(250);
    ellipse(valX, valY, 30, 30);
    
    // Zorgen dat het balletje relatief aan de score versnelt
    accell = score / 2 + 5;
    valY = valY + accell;
    

    // Als het balletje onderaan komt moet die weer boven beginnen en verder gaan
    // En als het balletje onderaan komt moet er 5 punten van de score worden gehaald
    if (valY > 600){
        valY = 0;
        valX = random(0,600);
        score = score - 5;
    }

    // Als het balletje op het balkje komt weer naar boven en verder gaan
    // en 1 punt aan de score toevoegen
    if(valY > 540){
        if(valX < rectX + 100 && valX > rectX){
            valY = 0;
            valX = random(0, 600);
            score = score + 1;
        }
    }

    // Geef de score weer
    fill(250);
    textSize(30);
    text(score, 50, 50);

    // Wat er gebeurd als je wint
    if(score == 30){
        background(0, 245, 0);
        text("You Win!", 250, 300);
        text("Click To Restart", 200, 350);
        gameOver = 1;
        valY = 300;
        valX= rectX + 50; 
    }
 
    // Wat er gebeurd als je verliest
    if(score < 0){
        background(255, 0, 0);
        text("You Lose", 250, 300);
        text("Click To Restart", 200, 350);
        gameOver = 1;
        valY = 300;
        valX = rectX + 50;

    }
    
}

// Het spel opnieuw laten starten als er gewonnen of verloren is, en iemand om je muisknop drukt
function mouseClicked(){
    if(gameOver == 1){
        reset();
    }
}
   